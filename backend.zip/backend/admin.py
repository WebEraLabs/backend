from django.contrib import admin

from backend.models import *

admin.site.register(Product)
admin.site.register(Categories)
admin.site.register(Pages)
admin.site.register(ProductGallery)
admin.site.register(Country)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(Payout)
admin.site.register(Cart)
admin.site.register(CartItem)



