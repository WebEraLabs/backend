from django.apps import AppConfig


class WebApisConfig(AppConfig):
    name = 'apis'
